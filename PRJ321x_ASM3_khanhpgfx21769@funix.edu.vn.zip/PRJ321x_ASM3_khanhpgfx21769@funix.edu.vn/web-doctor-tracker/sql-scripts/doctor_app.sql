DROP DATABASE  IF EXISTS `doctorcare`;

CREATE DATABASE  IF NOT EXISTS `doctorcare` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `doctorcare`;
-- SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `roles`;
CREATE TABLE roles (
    id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    role_name VARCHAR(255) NOT NULL
);
INSERT INTO `roles` (role_name)
VALUES ('ROLE_USER'),('ROLE_DOCTOR'),('ROLE_ADMIN');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
    id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) DEFAULT NULL,
    name VARCHAR(255) DEFAULT NULL,
    email VARCHAR(255) DEFAULT NULL,
    password VARCHAR(128) DEFAULT NULL,
    address VARCHAR(255) DEFAULT NULL,
    phone_number VARCHAR(255) DEFAULT NULL,
    avatar VARCHAR(255) DEFAULT NULL,
    gender VARCHAR(255) DEFAULT NULL,
    description VARCHAR(255) DEFAULT NULL,
    role_id INT(11) DEFAULT NULL,
    place_id INT(11) DEFAULT 1,
    is_active INT(11) DEFAULT 1,
    reset_token VARCHAR(255) DEFAULT NULL,
    note VARCHAR(255) DEFAULT NULL,
    background VARCHAR(255) DEFAULT NULL,
    consult_fee INT DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL,
    FOREIGN KEY (role_id) REFERENCES roles(id)
);

INSERT INTO `users` (username,password,name,email,role_id,place_id,background,consult_fee)
VALUES 
('john','$2a$04$eFytJDGtjbThXa80FyOOBuFdK2IwjyWefYkMpiBEFlpBwDH.5PM0K','John Doe','alphapham278@gmail.com',1,1,null,0),
('mary','$2a$04$eFytJDGtjbThXa80FyOOBuFdK2IwjyWefYkMpiBEFlpBwDH.5PM0K','Mary Public','mary@luv2code.com',2,1,'doctor',500000),
('jane','$2a$04$eFytJDGtjbThXa80FyOOBuFdK2IwjyWefYkMpiBEFlpBwDH.5PM0K','Jane Public','jane@luv2code.com',2,2,'doctor',450000),
('johnson','$2a$04$eFytJDGtjbThXa80FyOOBuFdK2IwjyWefYkMpiBEFlpBwDH.5PM0K','Johnson Stein','khanhgiaphambadboi@gmail.com',2,3,'doctor',700000),
('khanh','$2a$04$eFytJDGtjbThXa80FyOOBuFdK2IwjyWefYkMpiBEFlpBwDH.5PM0K','Khanh Pham','khanhphamgia53@gmail.com',2,1,'doctor',600000),
('raven','$2a$04$eFytJDGtjbThXa80FyOOBuFdK2IwjyWefYkMpiBEFlpBwDH.5PM0K','raven field','khanhindatabase@gmail.com',2,3,'doctor',500000),
('susan','$2a$04$eFytJDGtjbThXa80FyOOBuFdK2IwjyWefYkMpiBEFlpBwDH.5PM0K','Susan Adams','memenadeKhanh@gmail.com',3,1,null,0);

DROP TABLE IF EXISTS `clinics`;
CREATE TABLE `clinics`(
	id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) DEFAULT NULL,
    address VARCHAR(255) DEFAULT NULL,
    phone VARCHAR(255) DEFAULT NULL,
    description TEXT DEFAULT NULL,
    image VARCHAR(255) DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO `clinics` (name,description,address,phone)
VALUES
('Family Medical Practice Vietnam',
'This clinic offers comprehensive healthcare services with a team of international doctors',
'298 I Kim Ma Street, Hanoi',
'02438430748'),
('Vietlife Clinic - Sản Nhi',
'A well-known clinic in the Hoàn Kiếm district',
'14 Trần Bình Trọng, Hoàn Kiếm, Hanoi',
'02473078999'),
('Phòng Khám Hải Đăng - Lighthouse Community Clinic',
'A community-focused clinic',
'15a Ngõ 98 Vũ Trọng Phụng, Q. Thanh Xuân, Hanoi',
'0979693436');

DROP TABLE IF EXISTS `specializations`;
CREATE TABLE specializations(
	id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) DEFAULT NULL,
    description TEXT DEFAULT NULL,
    image VARCHAR(255),
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL
);

INSERT INTO `specializations` (name, description)
VALUES
('Pediatrics', 'Specializes in child healthcare'),
('Cardiology', 'Specializes in heart and blood vessel health'),
('Orthopedics', 'Specializes in bone and joint conditions');

DROP TABLE IF EXISTS `doctor_users`;
CREATE TABLE `doctor_users`(
	id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    doctor_id INT(11) DEFAULT NULL,
    clinic_id INT(11) DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_at DATETIME DEFAULT NULL,
	FOREIGN KEY (doctor_id) REFERENCES users(id),
    FOREIGN KEY (clinic_id) REFERENCES clinics(id)
);

DROP TABLE IF EXISTS `doctor_specializations`;
CREATE TABLE `doctor_specializations`(
	id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    doctor_id INT(11) DEFAULT NULL,
    specialization_id INT(11) DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
	updated_at DATETIME DEFAULT NULL,
	FOREIGN KEY (doctor_id) REFERENCES users(id),
    FOREIGN KEY (specialization_id) REFERENCES specializations(id)
);

INSERT INTO `doctor_users` (doctor_id, clinic_id)
VALUES
(2, 1),
(2, 3),
(3, 2),
(4, 2),
(5, 3),
(6, 3);

INSERT INTO `doctor_specializations` (doctor_id, specialization_id)
VALUES
(2, 1),
(2, 3),
(3, 2),
(4, 2),
(5, 3),
(6, 3);


DROP TABLE IF EXISTS `statuses`;
CREATE TABLE `statuses`(
	id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255),
    doctor_id INT(11) NOT NULL,
    clinic_id INT(11) NOT NULL,
    confirm_by_doctor BOOLEAN,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL,
    patient_id INT DEFAULT NULL,
    note VARCHAR(255) DEFAULT NULL,
    FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (clinic_id) REFERENCES clinics(id) ON DELETE CASCADE
);

DROP TABLE IF EXISTS `schedules`;
CREATE TABLE `schedules`(
	id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    doctor_id INT(11) NOT NULL,
    `date` VARCHAR(255),
    `time` VARCHAR(255),
    max_booking INT(11),
    sum_booking INT(11),
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL,
    FOREIGN KEY (doctor_id) REFERENCES users(id) ON DELETE CASCADE
);

INSERT INTO `schedules` (doctor_id, `date`, `time`, max_booking, sum_booking)
VALUES
(2, '2025-01-16', '09:00 AM', 10, 0),
(3, '2025-01-16', '10:00 AM', 15, 0);

DROP TABLE IF EXISTS `places`;
CREATE TABLE `places`(
	id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT NULL
);

INSERT INTO `places` (name)
VALUES ('Hanoi'), ('Saigon'), ('Danang');

DROP TABLE IF EXISTS `work_experience`;
CREATE TABLE work_experience (
    id INT AUTO_INCREMENT PRIMARY KEY,
    description VARCHAR(255),
    doctor_id INT
);
INSERT INTO work_experience (description, doctor_id) 
VALUES 
    ('Worked at General Hospital as Cardiologist from 2015 to 2020', 2),
    ('Pediatrician at City Clinic from 2010 to 2015', 3),
    ('Surgeon at HealthCare Center since 2021', 2);

DROP TABLE IF EXISTS `facilities`;
CREATE TABLE `facilities` (
    facilityId INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    facilityName VARCHAR(255) NOT NULL,
    unitNo VARCHAR(50) DEFAULT NULL,
    block VARCHAR(50) DEFAULT NULL,
    street VARCHAR(255) DEFAULT NULL,
    buildingName VARCHAR(255) DEFAULT NULL,
    regionState VARCHAR(255) DEFAULT NULL,
    city VARCHAR(255) DEFAULT NULL,
    country VARCHAR(255) DEFAULT NULL,
    postalCode VARCHAR(50) DEFAULT NULL,
    totalDoctor INT(11) DEFAULT 0,
    totalSpecialty INT(11) DEFAULT 0,
    totalSubSpecialty INT(11) DEFAULT 0,
    clinic_id INT(11) NOT NULL,
    FOREIGN KEY (clinic_id) REFERENCES clinics(id)
);

INSERT INTO `facilities` 
(facilityName, unitNo, block, street, buildingName, regionState, city, country, postalCode, totalDoctor, totalSpecialty, totalSubSpecialty, clinic_id)
VALUES
('Hanoi Medical Facility 1', '101', 'A', 'Kim Ma Street', 'Family Health Center', 'Ba Dinh', 'Hanoi', 'Vietnam', '100000', 25, 10, 5, 1),
('Hanoi Pediatric Center', '202', 'B', 'Nguyen Chi Thanh', 'Children’s Hospital', 'Dong Da', 'Hanoi', 'Vietnam', '100000', 30, 8, 3, 1),
('Hanoi Health Center', '303', 'C', 'Le Duan Street', 'Central Clinic', 'Hoan Kiem', 'Hanoi', 'Vietnam', '100000', 40, 12, 4, 2),
('Hanoi Family Clinic', '404', 'D', 'Pham Ngoc Thach', 'Care Building', 'Cau Giay', 'Hanoi', 'Vietnam', '100000', 35, 9, 2, 2),
('Hanoi Community Health Center', '505', 'E', 'Tran Phu Street', 'Lighthouse Clinic', 'Ha Dong', 'Hanoi', 'Vietnam', '100000', 20, 6, 1, 3),
('Hanoi Specialized Clinic', '606', 'F', 'Nguyen Van Linh', 'Specialist Tower', 'Thanh Xuan', 'Hanoi', 'Vietnam', '100000', 22, 7, 3, 3);

DROP TABLE IF EXISTS `medical_history`;
CREATE TABLE `medical_history`(
	id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
	diagnosis VARCHAR(255) NULL,
    treatment VARCHAR(255) NULL,
    user_id INT,
    FOREIGN KEY (user_id) REFERENCES `users`(id)
);

INSERT INTO `medical_history`(diagnosis, treatment, user_id) 
VALUES
('Flu','antibiotic',1),
('Gangerene','antibiotic',1);


-- code for testing--
-- SELECT cw.place_id FROM current_workplace cw JOIN users u ON cw.doctor_id = u.id WHERE cw.doctor_id = 2;
-- SELECT p.name FROM places p JOIN current_workplace cw JOIN users u ON cw.doctor_id = u.id AND cw.place_id = p.id WHERE cw.doctor_id = 2;
-- SELECT * FROM schedules s JOIN users u ON s.doctor_id = u.id;
-- SELECT s.* FROM schedules s JOIN users u ON s.doctor_id = u.id WHERE u.name = "Mary Public" AND s.time = "09:00 AM";
-- SELECT c.* FROM doctor_users du JOIN clinics c ON du.clinic_id = c.id WHERE du.doctor_id = 2 AND c.name = 'Family Medical Practice Vietnam';
-- SELECT c.* FROM clinics c JOIN doctor_users du ON du.clinic_id = c.id WHERE du.doctor_id = 2 AND c.id = 1;
-- SELECT DISTINCT u.* FROM users u JOIN statuses s ON u.id = s.patient_id WHERE s.doctor_id = 2;
-- SELECT 
--     s.id AS specialization_id,
--     s.name AS specialization_name,
--     s.description,
--     s.image,
--     s.created_at,
--     s.updated_at,
--     COUNT(du.id) AS doctor_count
-- FROM 
--     specializations s
-- LEFT JOIN 
--     doctor_users du ON s.id = du.specialization_id
-- GROUP BY 
--     s.id
-- ORDER BY 
--     doctor_count DESC;
-- code for testing--    
-- SELECT 
--     c.id AS clinic_id,
--     c.name AS clinic_name,
--     c.address,
--     c.phone,
--     c.description,
--     c.image,
--     c.created_at,
--     COUNT(du.id) AS doctor_count
-- FROM 
--     clinics c
-- LEFT JOIN 
--     doctor_users du ON c.id = du.clinic_id
-- GROUP BY 
--     c.id
-- ORDER BY 
--     doctor_count DESC;
-- code for testing--    
-- SELECT 
-- 	hf.id,
--     hf.name ,
--     hf.description,
--     hf.image
-- FROM 
--     clinics hf 
-- JOIN 
--     doctor_users du ON hf.id = du.clinic_id
-- GROUP BY 
--     hf.id 
-- ORDER BY 
--     COUNT(du.doctor_id) DESC;
-- SELECT 
--     u.id AS doctor_id,
--     p.name AS workplace,
--     u.name AS full_name,
--     u.gender,
--     u.avatar AS profileImageUrl,
--     GROUP_CONCAT(DISTINCT s.name SEPARATOR ', ') AS specialties,
--     cw.consult_fee,
--     GROUP_CONCAT(DISTINCT we.description SEPARATOR '; ') AS work_experience,
--     cw.background
-- FROM 
--     users u
-- LEFT JOIN current_workplace cw ON u.id = cw.doctor_id
-- LEFT JOIN places p ON cw.place_id = p.id
-- LEFT JOIN doctor_users du ON u.id = du.doctor_id
-- LEFT JOIN specializations s ON du.specialization_id = s.id
-- LEFT JOIN doctors_workexp dwe ON u.id = dwe.doctor_id
-- LEFT JOIN work_experience we ON dwe.workexp_id = we.id
-- WHERE 
--     u.role_id = 2 -- Ensures only doctors are included
-- GROUP BY 
--     u.id, p.name, cw.consult_fee, cw.background;
-- SELECT 
--     f.facilityId,
--     f.facilityName,
--     f.unitNo,
--     f.block,
--     f.street,
--     f.buildingName,
--     f.regionState,
--     f.city,
--     f.country,
--     f.postalCode,
--     f.totalDoctor,
--     f.totalSpecialty,
--     f.totalSubSpecialty,
--     c.name AS clinicName,
--     c.id AS clinicId
-- FROM 
--     facilities f
-- JOIN 
--     clinics c ON f.clinic_id = c.id;
